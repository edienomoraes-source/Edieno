package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.sql.Date;

import modelo.Cliente;
import modelo.Perfil;

public class ClienteDAO {
	
	// a conex�o com o banco de dados
		private Connection con;

		public ClienteDAO() {
			this.con = (Connection) ConexaoSingleton.getInstance();
		}

		public boolean adicionar(Cliente Cliente) {

			boolean retorno = false;

			String sql = "insert into Cliente "
					+ "(nome,email,senha,telefone, endereco,idperfil, dataNascimento)"
					+ " values (?,?,?,?,?,?,?)";

			try {
				// prepared statement para inser��o
				PreparedStatement stmt = con.prepareStatement(sql);

				// seta os valores (da ?) da instru��o SQL
				stmt.setString(1, Cliente.getNome());
				stmt.setString(2, Cliente.getEmail());
				stmt.setString(3, Cliente.getSenha());
				stmt.setString(4, Cliente.getTelefone());
				stmt.setString(5,  Cliente.getEndereco());
				stmt.setInt(6, Cliente.getPerfil().getIdPerfil());
				stmt.setDate(7, new Date(Cliente.getDataNascimento().getTimeInMillis()));

				// executa
				stmt.execute();
				stmt.close();
				retorno = true;

			} catch (SQLException e) {
				throw new RuntimeException(e);
			}

			return retorno;
		}

		public List<Cliente> getLista() {
			try {
				List<Cliente> listaClientes = new ArrayList<Cliente>();
				PreparedStatement stmt = this.con
						.prepareStatement("select  idCliente, nome, email, senha, telefone,endereco, dataNascimento, p.idPerfil, p.descricao from Cliente c, Perfil p where p.idPerfil");
				ResultSet rs = stmt.executeQuery();

				while (rs.next()) {
					// criando o objeto Cliente para adicionar na lista
					Cliente Cliente = new Cliente();
					Cliente.setIdCliente(rs.getInt("idCliente"));
					Cliente.setNome(rs.getString("nome"));
					Cliente.setEmail(rs.getString("email"));
					Cliente.setSenha(rs.getString("senha"));
					Cliente.setTelefone(rs.getString("telefone"));
					Cliente.setEndereco(rs.getString("endereco"));
					Perfil perfil = new Perfil();
					perfil.setIdPerfil(rs.getInt("idPerfil"));
					perfil.setDescricao(rs.getString("descricao"));
					Cliente.setPerfil(perfil);
					// montando a data atrav�s do Calendar
					Calendar data = Calendar.getInstance();
					data.setTime(rs.getDate("dataNascimento"));
					Cliente.setDataNascimento(data);

					// adicionando o objeto � lista
					listaClientes.add(Cliente);
				}
				rs.close();
				stmt.close();
				return listaClientes;
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}

		public Cliente obterCliente(int idCliente) {
			Cliente Cliente = new Cliente();
			try {
				PreparedStatement preparedStatement = con
						.prepareStatement("select  idCliente, nome, email, senha, telefone,endereco dataNascimento, p.idPerfil, p.descricao from Cliente c, Perfil p where c.idPerfil=p.idPerfil and idCliente = ?");
				preparedStatement.setLong(1, idCliente);
				ResultSet rs = preparedStatement.executeQuery();

				if (rs.next()) {
					// criando o objeto Cliente para adicionar na lista
					Cliente.setIdCliente(rs.getInt("idCliente"));
					Cliente.setNome(rs.getString("nome"));
					Cliente.setEmail(rs.getString("email"));
					Cliente.setSenha(rs.getString("senha"));
					Cliente.setTelefone(rs.getString("telefone"));
                    Cliente.setEndereco(rs.getString("endereco"));
                    Perfil perfil = new Perfil();
					perfil.setIdPerfil(rs.getInt("idPerfil"));
					perfil.setDescricao(rs.getString("descricao"));
					Cliente.setPerfil(perfil);

					// montando a data atrav�s do Calendar
					Calendar data = Calendar.getInstance();
					data.setTime(rs.getDate("dataNascimento"));
					Cliente.setDataNascimento(data);
				}
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}

			return Cliente;
		}

		public boolean alterar(Cliente Cliente) {
			boolean retorno = false;
			String sql = "update Cliente set nome=?, email=?, senha=?,"
					+ "telefone =?,endereco=?, idPerfil =?, dataNascimento=? where idCliente=?";

			try {
				PreparedStatement stmt = con.prepareStatement(sql);

				stmt.setString(1, Cliente.getNome());
				stmt.setString(2, Cliente.getEmail());
				stmt.setString(3, Cliente.getSenha());
				stmt.setString(4, Cliente.getTelefone());
				stmt.setString(5, Cliente.getEndereco());
			stmt.setInt(6, Cliente.getPerfil().getIdPerfil());
				stmt.setDate(8, new Date(Cliente.getDataNascimento().getTimeInMillis()));
				stmt.setLong(7, Cliente.getIdCliente());

				stmt.execute();
				stmt.close();
				retorno = true;
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
			return retorno;
		}
		
		public boolean remover(Cliente Cliente) {
	 	    boolean retorno = false; 
			try {
	 	         PreparedStatement stmt = con.prepareStatement("delete " +
	 	                 "from Cliente where idCliente=?");
	 	         stmt.setLong(1, Cliente.getIdCliente());
	 	         stmt.execute();
	 	         stmt.close();
	 	         retorno = true;
	 	     } catch (SQLException e) {
	 	         throw new RuntimeException(e);
	 	     }
			return retorno;
	 	 }
		
		public Cliente autenticar(Cliente c) {
			Cliente cliente = new Cliente();
			try {
				PreparedStatement preparedStatement = con
						.prepareStatement("select  idCliente, nome, email, senha, telefone,endereco, dataNascimento, p.idPerfil, p.descricao from Cliente c, Perfil p where c.idPerfil=p.idPerfil and email = ? and senha = ?");
				preparedStatement.setString(1, c.getEmail());
				preparedStatement.setString(2, c.getSenha());
				ResultSet rs = preparedStatement.executeQuery();

				if (rs.next()) {
					// criando o objeto Cliente para adicionar na lista
					cliente.setIdCliente(rs.getInt("idCliente"));
					cliente.setNome(rs.getString("nome"));
					cliente.setEmail(rs.getString("email"));
					cliente.setSenha(rs.getString("senha"));
					cliente.setTelefone(rs.getString("telefone"));
                    cliente.setEndereco(rs.getString("endereco"));
				
                    Perfil perfil = new Perfil();
					perfil.setIdPerfil(rs.getInt("idPerfil"));
					perfil.setDescricao(rs.getString("descricao"));
					cliente.setPerfil(perfil);
					// montando a data atrav�s do Calendar
					Calendar data = Calendar.getInstance();
					data.setTime(rs.getDate("dataNascimento"));
					cliente.setDataNascimento(data);
				}else {
					cliente = null;
				}
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}

			return cliente;
		}

}
