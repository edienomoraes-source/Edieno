package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.sql.Date;

import modelo.Veiculo;

public class veiculoDAO {
	
	// a conex�o com o banco de dados
		private Connection con;

		public veiculoDAO() {
			this.con = (Connection) ConexaoSingleton.getInstance();
		}

		public boolean adicionar(Veiculo veiculo) {

			boolean retorno = false;

			String sql = "insert into Veiculo "
					+ "(descricao,precolocacao, anolancamento)"
					+ " values (?,?,?)";

			try {
				// prepared statement para inser��o
				PreparedStatement stmt = con.prepareStatement(sql);

				// seta os valores (da ?) da instru��o SQL
				stmt.setString(1, veiculo.getDescricao());
				stmt.setDouble(2, veiculo.getPrecolocacao());
				stmt.setInt(3,veiculo.getAnolancamento());

				// executa
				stmt.execute();
				stmt.close();
				retorno = true;

			} catch (SQLException e) {
				throw new RuntimeException(e);
			}

			return retorno;
		}

		public List<Veiculo> getLista() {
			try {
				List<Veiculo> listaVeiculos = new ArrayList<Veiculo>();
				PreparedStatement stmt = this.con
						.prepareStatement("select * from Veiculo");
				ResultSet rs = stmt.executeQuery();

				while (rs.next()) {
					// criando o objeto Produto para adicionar na lista
					Veiculo veiculo = new Veiculo();
					veiculo.setIdVeiculo(rs.getInt("idVeiculo"));
					veiculo.setDescricao(rs.getString("descricao"));
					veiculo.setPrecolocacao(rs.getDouble("precolocacao"));
                    veiculo.setAnolancamento(rs.getInt("anolancamento"));
					
					listaVeiculos.add(veiculo);
				}
				rs.close();
				stmt.close();
				return listaVeiculos;
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}

		public Veiculo obterVeiculo(int idVeiculo) {
			Veiculo veiculo = new Veiculo();
			try {
				PreparedStatement preparedStatement = con
						.prepareStatement("select * from Veiculo where idVeiculo = ?");
				preparedStatement.setLong(1, idVeiculo);
				ResultSet rs = preparedStatement.executeQuery();

				if (rs.next()) {
					// criando o objeto Produto para adicionar na lista
					veiculo.setIdVeiculo(rs.getInt("idVeiculo"));
					veiculo.setDescricao(rs.getString("descricao"));
					veiculo.setPrecolocacao(rs.getDouble("precolocacao"));
					veiculo.setAnolancamento(rs.getInt("anolancamento"));
					
					
				}
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}

			return veiculo;
		}

		public boolean alterar(Veiculo veiculo) {
			boolean retorno = false;
			String sql = "update Veiculo set descricao=?, precolocacao=?, "
					+ " anolancamento=? where idVeiculo=?";

			try {
				PreparedStatement stmt = con.prepareStatement(sql);

				stmt.setString(1, veiculo.getDescricao());
				stmt.setDouble(2, veiculo.getPrecolocacao());
				stmt.setInt(3, veiculo.getAnolancamento());
				stmt.setLong(4, veiculo.getIdVeiculo());

				stmt.execute();
				stmt.close();
				retorno = true;
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
			return retorno;
		}
		
		public boolean remover(Veiculo veiculo) {
	 	    boolean retorno = false; 
			try {
	 	         PreparedStatement stmt = con.prepareStatement("delete " +
	 	                 "from Veiculo where idVeiculo=?");
	 	         stmt.setLong(1, veiculo.getIdVeiculo());
	 	         stmt.execute();
	 	         stmt.close();
	 	         retorno = true;
	 	     } catch (SQLException e) {
	 	         throw new RuntimeException(e);
	 	     }
			return retorno;
	 	 }

}
