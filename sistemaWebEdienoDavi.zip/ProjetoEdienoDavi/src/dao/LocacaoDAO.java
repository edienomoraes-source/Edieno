package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.sql.Date;

import modelo.Cliente;
import modelo.Locacao;
import modelo.Perfil;
import modelo.Veiculo;
public class LocacaoDAO {
	
	// a conex�o com o banco de dados
		private Connection con;

		public LocacaoDAO() {
			this.con = (Connection) ConexaoSingleton.getInstance();
		}

		public boolean adicionar(Locacao Locacao) {

			boolean retorno = false;

			String sql = "insert into Locacao "
					+ "(qtdDias,precoFinal,idCliente,idVeiculo)"
					+ " values (?,?,?,?)";

			try {
				// prepared statement para inser��o
				PreparedStatement stmt = con.prepareStatement(sql);

				// seta os valores (da ?) da instru��o SQL
				stmt.setInt(1, Locacao.getQtdDias());
				stmt.setDouble(2, Locacao.getPrecoFinal());
				stmt.setInt(3, Locacao.getCliente().getIdCliente());
				stmt.setInt(4, Locacao.getVeiculo().getIdVeiculo());
				
				// executa
				stmt.execute();
				stmt.close();
				retorno = true;

			} catch (SQLException e) {
				throw new RuntimeException(e);
			}

			return retorno;
		}

		public List<Locacao> getLista() {
			try {
				List<Locacao> listaLocacaos = new ArrayList<Locacao>();
				PreparedStatement stmt = this.con
						.prepareStatement("select  idLocacao, qtdDias, precoFinal , p.idCliente, p.nome,p.email,p.senha,p.telefone,p.endereco from Locacao c, Cliente p where c.idCliente=p.idCliente");
				ResultSet rs = stmt.executeQuery();

				while (rs.next()) {
					// criando o objeto Cliente para adicionar na lista
					Locacao Locacao = new Locacao();
					Locacao.setIdLocacao(rs.getInt("idLocacao"));
					Locacao.setQtdDias(rs.getInt("qtdDias"));
					Locacao.setPrecoFinal(rs.getDouble("precoFinal"));
					Cliente cliente = new Cliente();
					cliente.setIdCliente(rs.getInt("idCliente"));
					cliente.setNome(rs.getString("nome"));
					cliente.setEmail(rs.getString("email"));
					cliente.setSenha(rs.getString("senha"));
					cliente.setTelefone(rs.getString("telefone"));
					cliente.setEndereco(rs.getString("endereco"));
					Locacao.setCliente(cliente);
					Veiculo Veiculo= new Veiculo();
					Veiculo.setDescricao(rs.getString("descricao"));
					Veiculo.setPrecolocacao(rs.getDouble("precolocacao"));
					Veiculo.setDescricao(rs.getString("descricao"));
					Veiculo.setAnolancamento(rs.getInt("anolancamento"));
					Locacao.setVeiculo(Veiculo);
;
					// montando a data atrav�s do Calendar
					

					// adicionando o objeto � lista
					listaLocacaos.add(Locacao);
				}
				rs.close();
				stmt.close();
				return listaLocacaos;
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}

		public Locacao obterLocacao(int idLocacao) {
			Locacao Locacao = new Locacao();
			try {
				PreparedStatement preparedStatement = con
						.prepareStatement("select  idLocacao, qtdDias, precoFinal , p.idCliente, p.nome,p.email,p.senha,p.telefone,p.endereco from Locacao c, Cliente p where c.idCliente=p.idCliente\"");
				preparedStatement.setLong(1, idLocacao);
				ResultSet rs = preparedStatement.executeQuery();

				if (rs.next()) {
					// criando o objeto Cliente para adicionar na lista
					Locacao.setIdLocacao(rs.getInt("idLocacao"));
					Locacao.setQtdDias(rs.getInt("qtdDias"));
					Locacao.setPrecoFinal(rs.getDouble("precoFinal"));
					Cliente cliente = new Cliente();
					cliente.setIdCliente(rs.getInt("idCliente"));
					cliente.setNome(rs.getString("nome"));
					cliente.setEmail(rs.getString("email"));
					cliente.setSenha(rs.getString("senha"));
					cliente.setTelefone(rs.getString("telefone"));
					cliente.setEndereco(rs.getString("endereco"));
					Locacao.setCliente(cliente);
					Veiculo Veiculo= new Veiculo();
					Veiculo.setDescricao(rs.getString("descricao"));
					Veiculo.setPrecolocacao(rs.getDouble("precolocacao"));
					Veiculo.setDescricao(rs.getString("descricao"));
					Veiculo.setAnolancamento(rs.getInt("anolancamento"));
					Locacao.setVeiculo(Veiculo);

					// montando a data atrav�s do Calendar
					
				}
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}

			return Locacao;
		}

		public boolean alterar(Locacao Locacao) {
			boolean retorno = false;
			String sql = "update Locacao set qtdDias=?, PrecoFnal=?, "
					+ "idCliente, idVeiculo where idLocacao=?";

			try {
				PreparedStatement stmt = con.prepareStatement(sql);

				stmt.setInt(1, Locacao.getQtdDias());
				stmt.setDouble(2, Locacao.getPrecoFinal());
				stmt.setInt(3, Locacao.getCliente().getIdCliente());
				stmt.setInt(4, Locacao.getVeiculo().getIdVeiculo());
				stmt.setLong(5, Locacao.getIdLocacao());

				stmt.execute();
				stmt.close();
				retorno = true;
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
			return retorno;
		}
		
		public boolean remover(Locacao locacao) {
	 	    boolean retorno = false; 
			try {
	 	         PreparedStatement stmt = con.prepareStatement("delete " +
	 	                 "from Cliente where idLocacao=?");
	 	         stmt.setLong(1, locacao.getIdLocacao());
	 	         stmt.execute();
	 	         stmt.close();
	 	         retorno = true;
	 	     } catch (SQLException e) {
	 	         throw new RuntimeException(e);
	 	     }
			return retorno;
	 	 }
		
		
}
