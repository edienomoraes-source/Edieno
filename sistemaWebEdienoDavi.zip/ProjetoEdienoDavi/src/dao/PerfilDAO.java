package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.sql.Date;

import modelo.Perfil;

public class PerfilDAO {
	
	// a conex�o com o banco de dados
		private Connection con;

		public PerfilDAO() {
			this.con = (Connection) ConexaoSingleton.getInstance();
		}

		public boolean adicionar(Perfil Perfil) {

			boolean retorno = false;

			String sql = "insert into Perfil "
					+ "(descricao)"
					+ " values (?)";

			try {
				// prepared statement para inser��o
				PreparedStatement stmt = con.prepareStatement(sql);

				// seta os valores (da ?) da instru��o SQL
				stmt.setString(1, Perfil.getDescricao());
				
				// executa
				stmt.execute();
				stmt.close();
				retorno = true;

			} catch (SQLException e) {
				throw new RuntimeException(e);
			}

			return retorno;
		}

		public List<Perfil> getLista() {
			try {
				List<Perfil> listaPerfils = new ArrayList<Perfil>();
				PreparedStatement stmt = this.con
						.prepareStatement("select * from Perfil");
				ResultSet rs = stmt.executeQuery();

				while (rs.next()) {
					// criando o objeto Perfil para adicionar na lista
					Perfil Perfil = new Perfil();
					Perfil.setIdPerfil(rs.getInt("idPerfil"));
					Perfil.setDescricao(rs.getString("descricao"));
					

					// adicionando o objeto � lista
					listaPerfils.add(Perfil);
				}
				rs.close();
				stmt.close();
				return listaPerfils;
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
		}

		public Perfil obterPerfil(int idPerfil) {
			Perfil Perfil = new Perfil();
			try {
				PreparedStatement preparedStatement = con
						.prepareStatement("select * from Perfil where idPerfil = ?");
				preparedStatement.setLong(1, idPerfil);
				ResultSet rs = preparedStatement.executeQuery();

				if (rs.next()) {
					// criando o objeto Perfil para adicionar na lista
					Perfil.setIdPerfil(rs.getInt("idPerfil"));
					Perfil.setDescricao(rs.getString("descricao"));
					
				}
			} catch (SQLException e) {
				System.out.println(e.getMessage());
			}

			return Perfil;
		}

		public boolean alterar(Perfil Perfil) {
			boolean retorno = false;
			String sql = "update Perfil set descricao=? where idPerfil=?";

			try {
				PreparedStatement stmt = con.prepareStatement(sql);

				stmt.setString(1, Perfil.getDescricao());
				stmt.setLong(2, Perfil.getIdPerfil());

				stmt.execute();
				stmt.close();
				retorno = true;
			} catch (SQLException e) {
				throw new RuntimeException(e);
			}
			return retorno;
		}
		
		public boolean remover(Perfil Perfil) {
	 	    boolean retorno = false; 
			try {
	 	         PreparedStatement stmt = con.prepareStatement("delete " +
	 	                 "from Perfil where idPerfil=?");
	 	         stmt.setLong(1, Perfil.getIdPerfil());
	 	         stmt.execute();
	 	         stmt.close();
	 	         retorno = true;
	 	     } catch (SQLException e) {
	 	         throw new RuntimeException(e);
	 	     }
			return retorno;
	 	 }

}
