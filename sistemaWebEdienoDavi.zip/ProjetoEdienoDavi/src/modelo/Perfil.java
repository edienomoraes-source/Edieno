package modelo;

public class Perfil {
private int idPerfil;
private String descricao;
public int getIdPerfil() {
	return idPerfil;
}
public void setIdPerfil(int idPerfil) {
	this.idPerfil = idPerfil;
}
public String getDescricao() {
	return descricao;
}
public void setDescricao(String descricao) {
	this.descricao = descricao;
}

}
