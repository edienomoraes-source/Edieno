package modelo;

public class VeiculosLocacao {
	private int idVeiculosLocacao;
	private Veiculo veiculo;
	public int getIdVeiculosLocacao() {
		return idVeiculosLocacao;
	}
	public void setIdVeiculosLocacao(int idVeiculosLocacao) {
		this.idVeiculosLocacao = idVeiculosLocacao;
	}
	public Veiculo getVeiculo() {
		return veiculo;
	}
	public void setVeiculo(Veiculo veiculo) {
		this.veiculo = veiculo;
	}
}
