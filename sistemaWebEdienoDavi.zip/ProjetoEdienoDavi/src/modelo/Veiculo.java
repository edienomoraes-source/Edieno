package modelo;

import java.util.Calendar;

public class Veiculo {
	
private int idVeiculo;
private String descricao;
private double precolocacao;
private int anolancamento;
public int getIdVeiculo() {
	return idVeiculo;
}
public void setIdVeiculo(int idVeiculo) {
	this.idVeiculo = idVeiculo;
}
public String getDescricao() {
	return descricao;
}
public void setDescricao(String descricao) {
	this.descricao = descricao;
}
public double getPrecolocacao() {
	return precolocacao;
}
public void setPrecolocacao(double precolocacao) {
	this.precolocacao = precolocacao;
}
public int getAnolancamento() {
	return anolancamento;
}
public void setAnolancamento(int anolancamento) {
	anolancamento = anolancamento;
}

}
