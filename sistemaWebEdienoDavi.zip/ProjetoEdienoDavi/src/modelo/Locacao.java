package modelo;

import java.util.ArrayList;
import java.util.Calendar;

public class Locacao {

	private int idLocacao;
	private Cliente cliente;
	private int qtdDias;
	
	private double precoFinal;
	private ArrayList<VeiculosLocacao>veiculosLocacao;
	public ArrayList<VeiculosLocacao> getVeiculosLocacao() {
		return veiculosLocacao;
	}
	public void setVeiculosLocacao(ArrayList<VeiculosLocacao> veiculosLocacao) {
		this.veiculosLocacao = veiculosLocacao;
	}
	public int getIdLocacao() {
		return idLocacao;
	}
	public void setIdLocacao(int idLocacao) {
		this.idLocacao = idLocacao;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
	
	
	public int getQtdDias() {
		return qtdDias;
	}
	public void setQtdDias(int qtdDias) {
		this.qtdDias = qtdDias;
	}
	
	public double getPrecoFinal() {
		return precoFinal;
	}
	public void setPrecoFinal(double precoFinal) {
		this.precoFinal = precoFinal;
	}
	public Veiculo getVeiculo() {
		// TODO Auto-generated method stub
		return null;
	}
	public void setVeiculo(Veiculo veiculo) {
		// TODO Auto-generated method stub
		
	}
}
