package control;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.veiculoDAO;
import modelo.Veiculo;

/**
 * Servlet implementation class VeiculoControlador
 */
@WebServlet("/VeiculoControlador")
public class VeiculoControlador extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private veiculoDAO veiculoDAO;
	private static String INSERT = "/cadastarVeiculo.jsp";
    private static String EDIT = "/cadastarVeiculo.jsp";
    private static String LIST = "/moduloVeiculo.jsp";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public VeiculoControlador() {
        super();
        veiculoDAO = new veiculoDAO();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String forward="";
        String action = request.getParameter("action");

        if (action.equalsIgnoreCase("delete")){
        	
        	Veiculo veiculo = new Veiculo();
        	int idVeiculo = Integer.parseInt(request.getParameter("idVeiculo"));
        	veiculo.setIdVeiculo(idVeiculo);
        	veiculoDAO.remover(veiculo);
            forward = LIST;
            request.setAttribute("veiculos", veiculoDAO.getLista());
            
        } else if (action.equalsIgnoreCase("edit")){
        	
        	forward = EDIT;
            
        	int idVeiculo = Integer.parseInt(request.getParameter("idVeiculo"));
            Veiculo veiculo = veiculoDAO.obterVeiculo(idVeiculo);
            
            request.setAttribute("veiculo", veiculo);
            
        } else if (action.equalsIgnoreCase("listarVeiculos")){
            
        	forward = LIST;
            request.setAttribute("veiculos", veiculoDAO.getLista());
            
        } else {
        	
            forward = INSERT;
        }

        RequestDispatcher view = request.getRequestDispatcher(forward);
        view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Veiculo veiculo = new Veiculo();
		
		String descricao = request.getParameter("descricao");
		veiculo.setDescricao(descricao);
		
		Double precolocacao = Double.parseDouble(request.getParameter("precolocacao"));
		veiculo.setPrecolocacao(precolocacao);
		
		int anolancamento = Integer.parseInt(request.getParameter("anolancamento"));
		veiculo.setAnolancamento(anolancamento);
		

		String idVeiculo = request.getParameter("idVeiculo");
		 if(idVeiculo == null || idVeiculo.isEmpty())
	    {
			 veiculoDAO.adicionar(veiculo);
	    }
	    else
	    {
	            veiculo.setIdVeiculo(Integer.parseInt(idVeiculo));
	            veiculoDAO.alterar(veiculo);
	    }
	        RequestDispatcher view = request.getRequestDispatcher(LIST);
	        request.setAttribute("veiculoa", veiculoDAO.getLista());
	        view.forward(request, response);
		
		
	}
		
}
