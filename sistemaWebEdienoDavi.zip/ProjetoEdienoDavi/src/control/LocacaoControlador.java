
package control;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ClienteDAO;
import dao.veiculoDAO;
import dao.LocacaoDAO;
import modelo.Cliente;
import modelo.Locacao;
import modelo.Perfil;
import modelo.Veiculo;
import dao.PerfilDAO;

/**
 * Servlet implementation class clienteControlador
 */
@WebServlet("/LocacaoControlador")
public class LocacaoControlador extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ClienteDAO clienteDAO;
	private veiculoDAO veiculoDAO;
	private LocacaoDAO LocacaoDAO;
	private PerfilDAO perfilDAO;
	private static String INSERT = "/cadastroLocacao.jsp";
    private static String EDIT = "/cadastroLocacao.jsp";
    private static String LIST = "/moduloLocacao.jsp";
    private static String INICIO = "/index.jsp";
    private static String ADM = "/Inicio.jsp";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LocacaoControlador() {
        super();
        clienteDAO = new ClienteDAO();
        veiculoDAO = new veiculoDAO();
        LocacaoDAO = new LocacaoDAO();
        
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String forward="";
        String action = request.getParameter("action");

        if (action.equalsIgnoreCase("delete")){
        	
        	Locacao locacao = new Locacao();
        	int idLocacao = Integer.parseInt(request.getParameter("idLocacao"));
        	locacao.setIdLocacao(idLocacao);
        	LocacaoDAO.remover(locacao);
            forward = LIST;
            request.setAttribute("locacaos", LocacaoDAO.getLista());
            
        } else if (action.equalsIgnoreCase("edit")){
        	
        	forward = EDIT;
            
        	int idLocacao = Integer.parseInt(request.getParameter("idLocacao"));
            Locacao locacao = LocacaoDAO.obterLocacao(idLocacao);
            
            request.setAttribute("locacao", locacao);
            
        } else if (action.equalsIgnoreCase("listarLocacaos")){
            
        	forward = LIST;
            request.setAttribute("locacaos", LocacaoDAO.getLista());
        }else if(action.equalsIgnoreCase("registrar")) {
        	
        	request.setAttribute("veiculos", veiculoDAO.getLista());
        	request.setAttribute("clientes", clienteDAO.getLista());
        }else {
        	
        	request.setAttribute("veiculos", veiculoDAO.getLista());
        	request.setAttribute("clientes", clienteDAO.getLista());
        	//request.setAttribute("perfils", perfilDAO.getLista());
            forward = INSERT;
        }


        RequestDispatcher view = request.getRequestDispatcher(forward);
        view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
			Locacao locacao = new Locacao();
			
			int qtdDias = Integer.parseInt(request.getParameter("qtdDias"));
			locacao.setQtdDias(qtdDias);
			
			Double precoFinal = Double.parseDouble(request.getParameter("precoFinal"));
			locacao.setPrecoFinal(precoFinal);
			
			Cliente cliente = new Cliente();
			cliente.setIdCliente(Integer.parseInt(request.getParameter("idCliente")));
			locacao.setCliente(cliente);

			Veiculo veiculo = new Veiculo();
			veiculo.setIdVeiculo(Integer.parseInt(request.getParameter("idVeiculo")));
			locacao.setVeiculo(veiculo);

			//String email = Intergrequest.getParameter("email");
			//cliente.setEmail(email);
			
			//String senha = request.getParameter("senha");
			//cliente.setSenha(senha);
			
			//String telefone = request.getParameter("telefone");
			//cliente.setTelefone(telefone);
			
			//String endereco = request.getParameter("endereco");
			////cliente.setEndereco(endereco);
		//	Perfil perfil = new Perfil();
		//perfil.setIdPerfil(Integer.parseInt(request.getParameter("idPerfil")));
		//	cliente.setPerfil(perfil);
			
			
			String idLocacao = request.getParameter("idLocacao");
			 if(idLocacao == null || idLocacao.isEmpty())
		    {
				 LocacaoDAO.adicionar(locacao);
		    }
		    else
		    {
		         locacao.setIdLocacao(Integer.parseInt(idLocacao));
		            LocacaoDAO.alterar(locacao);
		    }
		    RequestDispatcher view = request.getRequestDispatcher(LIST);
	        request.setAttribute("locacaos", LocacaoDAO.getLista());
	        view.forward(request, response);
	     }
	}

	    
		
	
		
