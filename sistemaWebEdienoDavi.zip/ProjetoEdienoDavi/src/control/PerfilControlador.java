package control;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.PerfilDAO;
import modelo.Perfil;

/**
 * Servlet implementation class perfilControlador
 */
@WebServlet("/PerfilControlador")
public class PerfilControlador extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private PerfilDAO perfilDAO;
	private static String INSERT = "/cadastroPerfil.jsp";
    private static String EDIT = "/cadastroPerfil.jsp";
    private static String LIST = "/moduloPerfil.jsp";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PerfilControlador() {
        super();
        perfilDAO = new PerfilDAO();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String forward="";
        String action = request.getParameter("action");

        if (action.equalsIgnoreCase("delete")){
        	
        	Perfil perfil = new Perfil();
        	int idPerfil = Integer.parseInt(request.getParameter("idPerfil"));
        	perfil.setIdPerfil(idPerfil);
        	perfilDAO.remover(perfil);
            forward = LIST;
            request.setAttribute("perfils", perfilDAO.getLista());
            
        } else if (action.equalsIgnoreCase("edit")){
        	
        	forward = EDIT;
            
        	int idPerfil = Integer.parseInt(request.getParameter("idPerfil"));
            Perfil perfil = perfilDAO.obterPerfil(idPerfil);
            
            request.setAttribute("perfil", perfil);
            
        } else if (action.equalsIgnoreCase("listarPerfils")){
            
        	forward = LIST;
            request.setAttribute("perfils", perfilDAO.getLista());
            
        } else {
        	
            forward = INSERT;
        }

        RequestDispatcher view = request.getRequestDispatcher(forward);
        view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Perfil perfil = new Perfil();
		
		String descricao = request.getParameter("descricao");
		perfil.setDescricao(descricao);
		
		
		
		String idPerfil = request.getParameter("idPerfil");
		 if(idPerfil == null || idPerfil.isEmpty())
	    {
			 perfilDAO.adicionar(perfil);
	    }
	    else
	    {
	            perfil.setIdPerfil(Integer.parseInt(idPerfil));
	            perfilDAO.alterar(perfil);
	    }
	        RequestDispatcher view = request.getRequestDispatcher(LIST);
	        request.setAttribute("perfils", perfilDAO.getLista());
	        view.forward(request, response);
		
		
	}
		
}
