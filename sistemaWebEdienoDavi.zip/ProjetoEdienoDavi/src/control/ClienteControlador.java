package control;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import dao.ClienteDAO;
import dao.PerfilDAO;
import modelo.Cliente;
import modelo.Perfil;

/**
 * Servlet implementation class clienteControlador
 */
@WebServlet("/ClienteControlador")
public class ClienteControlador extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private ClienteDAO clienteDAO;
	private PerfilDAO perfilDAO;
	private static String INSERT = "/cadastroCliente.jsp";
    private static String EDIT = "/cadastroCliente.jsp";
    private static String LIST = "/moduloCliente.jsp";
    private static String INICIO = "/menu.jsp";
    private static String ADM = "/moduloAdmnistrador.jsp";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ClienteControlador() {
        super();
        clienteDAO = new ClienteDAO();
        perfilDAO = new PerfilDAO();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String forward="";
        String action = request.getParameter("action");

        if (action.equalsIgnoreCase("delete")){
        	
        	Cliente cliente = new Cliente();
        	int idCliente = Integer.parseInt(request.getParameter("idCliente"));
        	cliente.setIdCliente(idCliente);
        	clienteDAO.remover(cliente);
            forward = LIST;
            request.setAttribute("clientes", clienteDAO.getLista());
            
        } else if (action.equalsIgnoreCase("edit")){
        	
        	forward = EDIT;
            
        	int idCliente = Integer.parseInt(request.getParameter("idCliente"));
            Cliente cliente = clienteDAO.obterCliente(idCliente);
            request.setAttribute("perfils", perfilDAO.getLista());

            request.setAttribute("cliente", cliente);
            
        } else if (action.equalsIgnoreCase("listarClientes")){
            
        	forward = LIST;
            request.setAttribute("clientes", clienteDAO.getLista());
            
        }else if(action.equalsIgnoreCase("sair")) {
        	HttpSession session = request.getSession();
        	session.removeAttribute("sessaoCliente");
        	session.invalidate();
        	forward = INICIO;
	    }else {
	    	request.setAttribute("perfils", perfilDAO.getLista());
            forward = INSERT;
        }

        RequestDispatcher view = request.getRequestDispatcher(forward);
        view.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String forward="";
        String action = request.getParameter("action");
        System.out.println("A��o = " +action);
	    if(action.equalsIgnoreCase("autenticar")) {
	    	Cliente cliente = new Cliente();
	    	String email = request.getParameter("email");
			cliente.setEmail(email);
			
			String senha = request.getParameter("senha");
			cliente.setSenha(senha);
			
			Cliente clienteRetorno = clienteDAO.autenticar(cliente);
			if(clienteRetorno!=null) {
				HttpSession session = request.getSession();
				session.setAttribute("sessaoCliente", clienteRetorno);

				
			}else {
				request.setAttribute("msg", "Credenciais inv�lidas! Tente novamente.");
				forward = INICIO;
			}
			RequestDispatcher view = request.getRequestDispatcher(forward);
	        view.forward(request, response);
	    }else {
			Cliente cliente = new Cliente();
			
			String nome = request.getParameter("nome");
			cliente.setNome(nome);
			
			String email = request.getParameter("email");
			cliente.setEmail(email);
			
			String senha = request.getParameter("senha");
			cliente.setSenha(senha);
			
			String telefone = request.getParameter("telefone");
			cliente.setTelefone(telefone);
			
			String endereco = request.getParameter("endereco");
			cliente.setEndereco(endereco);
			
			//Perfil possui relacionamento com Cliente
		Perfil perfil = new Perfil();
			perfil.setIdPerfil(Integer.parseInt(request.getParameter("idPerfil")));
			cliente.setPerfil(perfil);
			
			System.out.println("DATA V2 => " +  request.getParameter("dataNascimento"));
			//Pegar a DATA
			try {
				Calendar data = Calendar.getInstance();
				Date dataNascimento = new SimpleDateFormat("yyyy-MM-dd").parse(request.getParameter("dataNascimento"));
	            data.setTime(dataNascimento);
				cliente.setDataNascimento(data);
			} catch (ParseException e) {
				System.out.println(e.getMessage());
			}
			
			String idCliente = request.getParameter("idCliente");
			 if(idCliente == null || idCliente.isEmpty())
		    {
				 clienteDAO.adicionar(cliente);
		    }
		    else
		    {
		            cliente.setIdCliente(Integer.parseInt(idCliente));
		            clienteDAO.alterar(cliente);
		    }
		    RequestDispatcher view = request.getRequestDispatcher(LIST);
	        request.setAttribute("clientes", clienteDAO.getLista());
	        view.forward(request, response);
	    }
	    
		
	}
		
}
